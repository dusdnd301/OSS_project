package com.buskspot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuskspotApplicationTests {

	@Test
	void contextLoads() {
	}

}
