package com.buskspot.repository;

import com.buskspot.domain.EquipmentRental;
import com.buskspot.domain.EquipmentRental.RentalStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EquipmentRentalRepository extends JpaRepository<EquipmentRental, Long> {

    List<EquipmentRental> findByStatus(RentalStatus status);


    List<EquipmentRental> findTop10ByUserIdOrderByRentDateAsc(Long userId);

    void deleteAllByUserId(Long userId);
}
