package com.buskspot.domain;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "schedule")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Schedule {

    public enum RegistrationStatus {
        PENDING,
        APPROVED,
        REJECTED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;


    @Column(nullable = false)
    private String title;


    @Column(nullable = false)
    private String location;


    @Column(nullable = false)
    private String date;


    @Column(nullable = false)
    private String performerEmail;


    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RegistrationStatus status;
}
