package com.buskspot.domain;

import com.buskspot.entity.User;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Getter
@Setter
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class EquipmentRental {

    public enum RentalStatus {
        PENDING, APPROVED, REJECTED
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String equipmentName;

    private String renterName;

    private LocalDate rentDate;
    private LocalDate returnDate;

    @Enumerated(EnumType.STRING)
    private RentalStatus status;

    @ManyToOne(fetch = FetchType.LAZY)
    private User user;
}
