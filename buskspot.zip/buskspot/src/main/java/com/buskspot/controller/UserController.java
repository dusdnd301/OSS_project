package com.buskspot.controller;

import com.buskspot.entity.User;
import com.buskspot.repository.UserRepository;
import com.buskspot.repository.ScheduleRepository;
import com.buskspot.repository.EquipmentRentalRepository;
import com.buskspot.security.JwtUtil;
import org.springframework.http.*;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {

    private final UserRepository userRepository;
    private final ScheduleRepository scheduleRepository;
    private final EquipmentRentalRepository rentalRepository;
    private final JwtUtil jwtUtil;

    public UserController(UserRepository userRepository,
                          ScheduleRepository scheduleRepository,
                          EquipmentRentalRepository rentalRepository,
                          JwtUtil jwtUtil) {
        this.userRepository        = userRepository;
        this.scheduleRepository    = scheduleRepository;
        this.rentalRepository      = rentalRepository;
        this.jwtUtil               = jwtUtil;
    }

    @GetMapping("/me")
    public ResponseEntity<?> getMyInfo(@RequestHeader("Authorization") String authHeader) {
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("No token");
        }

        String token = authHeader.substring(7);
        if (!jwtUtil.validate(token)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid token");
        }

        String email = jwtUtil.getUsername(token);
        User user = userRepository.findByEmail(email).orElse(null);
        if (user == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body("User not found");
        }

        user.setPassword(null);
        return ResponseEntity.ok(user);
    }

    /**
     * 회원 탈퇴
     * - 연관된 공연 일정과 장비 대여 기록을 먼저 삭제한 뒤
     *   users 테이블에서 해당 사용자를 삭제합니다.
     */
    @Transactional
    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteUser(@RequestParam Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("사용자를 찾을 수 없습니다. id=" + userId));


        scheduleRepository.deleteAllByPerformerEmail(user.getEmail());


        rentalRepository.deleteAllByUserId(user.getId());


        userRepository.delete(user);

        return ResponseEntity.ok("회원 탈퇴가 완료되었습니다.");
    }
}
