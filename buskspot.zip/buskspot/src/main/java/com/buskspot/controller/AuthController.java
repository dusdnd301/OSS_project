package com.buskspot.controller;

import com.buskspot.entity.User;
import com.buskspot.repository.UserRepository;
import com.buskspot.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*")
public class AuthController {

    @Autowired private UserRepository userRepository;
    @Autowired private BCryptPasswordEncoder passwordEncoder;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (userRepository.findByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body("이미 존재하는 이메일입니다.");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        user.setRole("USER");
        User saved = userRepository.save(user);

        Map<String,Object> result = new HashMap<>();
        result.put("email",    saved.getEmail());
        result.put("nickname", saved.getNickname());
        result.put("role",     saved.getRole());
        return ResponseEntity.ok(result);
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User loginData) {

        if ("admin@admin.com".equals(loginData.getEmail())
                && "admin".equals(loginData.getPassword())) {

            Map<String,Object> adminUser = new HashMap<>();
            adminUser.put("id",       0);
            adminUser.put("email",    "admin@admin.com");
            adminUser.put("nickname", "관리자");
            adminUser.put("role",     "ADMIN");


            String token = jwtUtil.generateToken("admin@admin.com", "ADMIN");

            return ResponseEntity.ok(Map.of(
                    "token", token,
                    "user",  adminUser
            ));
        }


        Optional<User> userOpt = userRepository.findByEmail(loginData.getEmail());
        if (userOpt.isPresent()) {
            User dbUser = userOpt.get();
            if (passwordEncoder.matches(loginData.getPassword(), dbUser.getPassword())) {
                Map<String,Object> normalUser = new HashMap<>();
                normalUser.put("id",       dbUser.getId());
                normalUser.put("email",    dbUser.getEmail());
                normalUser.put("nickname", dbUser.getNickname());
                normalUser.put("role",     dbUser.getRole());


                String token = jwtUtil.generateToken(dbUser.getEmail(), dbUser.getRole());

                return ResponseEntity.ok(Map.of(
                        "token", token,
                        "user",  normalUser
                ));
            }
        }
        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                .body("이메일 또는 비밀번호가 틀렸습니다.");
    }
}
