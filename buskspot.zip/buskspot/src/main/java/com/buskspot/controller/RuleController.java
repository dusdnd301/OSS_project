package com.buskspot.controller;

import com.buskspot.entity.Rule;
import com.buskspot.service.RuleService;
import lombok.*;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rules")
@CrossOrigin(origins = "*")
public class RuleController {

    private final RuleService ruleService;

    public RuleController(RuleService ruleService) {
        this.ruleService = ruleService;
    }


    @GetMapping
    public ResponseEntity<RuleDTO> getRule() {
        Rule r = ruleService.getLatestRule();
        if (r == null) {
            return ResponseEntity.ok(new RuleDTO(""));
        }
        return ResponseEntity.ok(new RuleDTO(r.getContent()));
    }


    @PostMapping
    public ResponseEntity<RuleDTO> saveRule(@RequestBody RuleDTO dto) {
        Rule saved = ruleService.saveRule(dto.getContent());
        return ResponseEntity.ok(new RuleDTO(saved.getContent()));
    }


    @Getter @Setter @NoArgsConstructor @AllArgsConstructor
    static class RuleDTO {
        private String content;
    }
}
