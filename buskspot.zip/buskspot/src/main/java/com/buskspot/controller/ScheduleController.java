package com.buskspot.controller;

import com.buskspot.domain.Schedule;
import com.buskspot.dto.ScheduleDTO;
import com.buskspot.entity.User;
import com.buskspot.repository.UserRepository;
import com.buskspot.service.ScheduleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/schedule")
@CrossOrigin(origins = "*")
public class ScheduleController {

    private final ScheduleService scheduleService;
    private final UserRepository userRepository;

    public ScheduleController(ScheduleService scheduleService,
                              UserRepository userRepository) {
        this.scheduleService = scheduleService;
        this.userRepository = userRepository;
    }


    @PostMapping("/request")
    public ResponseEntity<?> requestSchedule(@RequestBody ScheduleDTO dto) {

        User user = userRepository.findById(dto.getUserId()).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("사용자를 찾을 수 없습니다.");
        }


        Schedule schedule = Schedule.builder()
                .title(dto.getTitle())
                .location(dto.getLocation())
                .date(dto.getDate().toString())
                .performerEmail(user.getEmail())
                .status(Schedule.RegistrationStatus.PENDING)
                .build();


        Schedule saved = scheduleService.createSchedule(schedule);
        return ResponseEntity.ok(saved);
    }


    @GetMapping("/my")
    public ResponseEntity<?> getMySchedules(@RequestParam Long userId) {
        User user = userRepository.findById(userId).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("사용자를 찾을 수 없습니다.");
        }
        List<Schedule> list = scheduleService.getSchedulesByEmail(user.getEmail());
        return ResponseEntity.ok(list);
    }


    @GetMapping("/pending")
    public ResponseEntity<?> getPendingSchedules() {
        List<Schedule> list = scheduleService.getPendingSchedules();
        return ResponseEntity.ok(list);
    }


    @PutMapping("/approve/{id}")
    public ResponseEntity<?> approve(@PathVariable Long id) {
        try {
            scheduleService.approveSchedule(id);
            return ResponseEntity.ok("승인되었습니다.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @PutMapping("/reject/{id}")
    public ResponseEntity<?> reject(@PathVariable Long id) {
        try {
            scheduleService.rejectSchedule(id);
            return ResponseEntity.ok("거절되었습니다.");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllSchedules() {
        List<Schedule> all = scheduleService.getAllSchedules();
        return ResponseEntity.ok(all);
    }
}
