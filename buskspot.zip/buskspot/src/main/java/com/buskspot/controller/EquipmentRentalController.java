package com.buskspot.controller;

import com.buskspot.domain.EquipmentRental;
import com.buskspot.dto.EquipmentRentalRequestDTO;
import com.buskspot.entity.User;
import com.buskspot.repository.UserRepository;
import com.buskspot.service.EquipmentRentalService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/equipment")
@CrossOrigin(origins = "*")
public class EquipmentRentalController {

    private final EquipmentRentalService rentalService;
    private final UserRepository userRepository;

    public EquipmentRentalController(EquipmentRentalService rentalService, UserRepository userRepository) {
        this.rentalService = rentalService;
        this.userRepository = userRepository;
    }


    @PostMapping("/request")
    public ResponseEntity<?> requestRental(@RequestBody EquipmentRentalRequestDTO dto) {

        User user = userRepository.findById(dto.getUserId()).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().body("사용자를 찾을 수 없습니다.");
        }


        if (dto.getRentDate().isAfter(dto.getReturnDate())) {
            return ResponseEntity.badRequest().body("대여 시작일이 반납일보다 뒤에 있을 수 없습니다.");
        }


        EquipmentRental rental = EquipmentRental.builder()
                .equipmentName(dto.getEquipmentName())
                .user(user)
                .renterName(user.getNickname())
                .rentDate(dto.getRentDate())
                .returnDate(dto.getReturnDate())
                .status(EquipmentRental.RentalStatus.PENDING)
                .build();


        EquipmentRental saved = rentalService.rentEquipment(rental);
        return ResponseEntity.ok(saved);
    }



    @GetMapping("/my-rentals")
    public ResponseEntity<?> getUserRentals(@RequestParam Long userId) {
        List<EquipmentRental> rentals = rentalService.getRentalsByUserId(userId);
        return ResponseEntity.ok(rentals);
    }


    @GetMapping("/pending")
    public ResponseEntity<?> getPendingRentals() {
        List<EquipmentRental> pendingRentals = rentalService.getPendingRentals();
        return ResponseEntity.ok(pendingRentals);
    }


    @PutMapping("/approve/{id}")
    public ResponseEntity<?> approveRental(@PathVariable Long id) {
        try {
            EquipmentRental rental = rentalService.approveRental(id);
            return ResponseEntity.ok(rental);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @PutMapping("/reject/{id}")
    public ResponseEntity<?> rejectRental(@PathVariable Long id) {
        try {
            EquipmentRental rental = rentalService.rejectRental(id);
            return ResponseEntity.ok(rental);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }


    @GetMapping("/admin/all")
    public ResponseEntity<?> getAllRentals() {
        List<EquipmentRental> allRentals = rentalService.getAllRentals();
        return ResponseEntity.ok(allRentals);
    }
}
