package com.buskspot.security;

import com.buskspot.security.JwtUtil;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collections;

@Component
public class JwtFilter implements Filter {

    private final JwtUtil jwtUtil;

    public JwtFilter(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }

    @Override
    public void doFilter(ServletRequest req,
                         ServletResponse res,
                         FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest  request  = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;
        String path   = request.getRequestURI();
        String method = request.getMethod();


        if ("OPTIONS".equalsIgnoreCase(method) || isPublicPath(path)) {
            if ("OPTIONS".equalsIgnoreCase(method)) {
                response.setStatus(HttpServletResponse.SC_OK);
            } else {
                chain.doFilter(req, res);
            }
            return;
        }


        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Token missing");
            return;
        }
        String token = header.substring(7);


        if (!jwtUtil.validate(token)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Token invalid");
            return;
        }


        String username = jwtUtil.getUsername(token);
        String role     = jwtUtil.getRole(token);
        Authentication auth = new UsernamePasswordAuthenticationToken(
                username,
                null,
                Collections.singletonList(new SimpleGrantedAuthority("ROLE_" + role))
        );
        SecurityContextHolder.getContext().setAuthentication(auth);


        if (isAdminPath(path) && !"ADMIN".equals(role)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Not admin");
            return;
        }


        chain.doFilter(req, res);
    }


    private boolean isPublicPath(String path) {
        return

                path.equals("/") ||
                        path.endsWith(".html") ||
                        path.startsWith("/css/") ||
                        path.startsWith("/js/") ||
                        path.startsWith("/images/") ||
                        path.startsWith("/fonts/") ||
                        path.equals("/favicon.ico") ||
                        path.equals("/logo.png")
                        ||
                        path.startsWith("/api/auth/")
                        ||
                        path.equals("/api/rules") ||
                        path.startsWith("/api/rules/")
                        ||
                        path.equals("/api/schedule") ||
                        path.startsWith("/api/schedule/approved")
                        ||
                        path.equals("/api/schedule/my") ||
                        path.equals("/api/schedule/request")
                        ||
                        path.startsWith("/api/equipment/request") ||
                        path.equals("/api/equipment/my-rentals");
    }


    private boolean isAdminPath(String path) {
        return path.startsWith("/api/schedule/pending") ||
                path.startsWith("/api/schedule/approve") ||
                path.startsWith("/api/schedule/reject") ||
                path.startsWith("/api/schedule/admin") ||
                path.startsWith("/api/equipment/pending") ||
                path.startsWith("/api/equipment/approve") ||
                path.startsWith("/api/equipment/reject") ||
                path.startsWith("/api/equipment/admin");
    }
}
