package com.buskspot.dto;

import lombok.*;
import java.time.LocalDate;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ScheduleDTO {
    private Long userId;
    private String title;
    private String location;
    private LocalDate date;
}
