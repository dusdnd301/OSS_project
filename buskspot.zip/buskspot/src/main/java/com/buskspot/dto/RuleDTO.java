package com.buskspot.dto;

import lombok.*;

@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RuleDTO {
    private String content;
}
