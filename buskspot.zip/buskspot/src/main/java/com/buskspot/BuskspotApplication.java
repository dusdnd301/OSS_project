
package com.buskspot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuskspotApplication {
	public static void main(String[] args) {
		SpringApplication.run(BuskspotApplication.class, args);
	}
}
