package com.buskspot.service;

import com.buskspot.entity.Rule;
import com.buskspot.repository.RuleRepository;
import org.springframework.stereotype.Service;

@Service
public class RuleService {

    private final RuleRepository ruleRepository;

    public RuleService(RuleRepository ruleRepository) {
        this.ruleRepository = ruleRepository;
    }


    public Rule getLatestRule() {
        return ruleRepository.findTopByOrderByIdDesc().orElse(null);
    }


    public Rule saveRule(String content) {
        Rule rule = Rule.builder()
                .content(content)
                .build();
        return ruleRepository.save(rule);
    }
}
