package com.buskspot.service;

import com.buskspot.domain.Schedule;
import com.buskspot.domain.Schedule.RegistrationStatus;
import com.buskspot.repository.ScheduleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ScheduleService {

    private final ScheduleRepository scheduleRepository;

    public ScheduleService(ScheduleRepository scheduleRepository) {
        this.scheduleRepository = scheduleRepository;
    }


    public Schedule createSchedule(Schedule schedule) {
        schedule.setStatus(RegistrationStatus.PENDING);
        return scheduleRepository.save(schedule);
    }


    public List<Schedule> getSchedulesByEmail(String email) {
        return scheduleRepository.findTop10ByPerformerEmailOrderByDateAsc(email);
    }


    public List<Schedule> getPendingSchedules() {
        return scheduleRepository.findByStatus(RegistrationStatus.PENDING);
    }


    public void approveSchedule(Long id) {
        Schedule s = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 공연입니다."));
        s.setStatus(RegistrationStatus.APPROVED);
        scheduleRepository.save(s);
    }


    public void rejectSchedule(Long id) {
        Schedule s = scheduleRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("존재하지 않는 공연입니다."));
        s.setStatus(RegistrationStatus.REJECTED);
        scheduleRepository.save(s);
    }




    public List<Schedule> getAllSchedules() {
        return scheduleRepository.findAll();
    }
}
