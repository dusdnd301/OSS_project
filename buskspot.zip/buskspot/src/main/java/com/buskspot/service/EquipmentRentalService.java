package com.buskspot.service;

import com.buskspot.domain.EquipmentRental;
import com.buskspot.repository.EquipmentRentalRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EquipmentRentalService {

    private final EquipmentRentalRepository rentalRepository;

    public EquipmentRentalService(EquipmentRentalRepository rentalRepository) {
        this.rentalRepository = rentalRepository;
    }


    public List<EquipmentRental> getAllRentals() {
        return rentalRepository.findAll();
    }


    public EquipmentRental rentEquipment(EquipmentRental rental) {
        return rentalRepository.save(rental);
    }


    public List<EquipmentRental> getRentalsByUserId(Long userId) {
        return rentalRepository.findTop10ByUserIdOrderByRentDateAsc(userId);
    }


    public List<EquipmentRental> getPendingRentals() {
        return rentalRepository.findByStatus(EquipmentRental.RentalStatus.PENDING);
    }


    public EquipmentRental approveRental(Long id) {
        Optional<EquipmentRental> opt = rentalRepository.findById(id);
        if (opt.isEmpty()) {
            throw new IllegalArgumentException("대여 요청이 존재하지 않습니다.");
        }
        EquipmentRental rental = opt.get();
        rental.setStatus(EquipmentRental.RentalStatus.APPROVED);
        return rentalRepository.save(rental);
    }


    public EquipmentRental rejectRental(Long id) {
        Optional<EquipmentRental> opt = rentalRepository.findById(id);
        if (opt.isEmpty()) {
            throw new IllegalArgumentException("대여 요청이 존재하지 않습니다.");
        }
        EquipmentRental rental = opt.get();
        rental.setStatus(EquipmentRental.RentalStatus.REJECTED);
        return rentalRepository.save(rental);
    }
}
